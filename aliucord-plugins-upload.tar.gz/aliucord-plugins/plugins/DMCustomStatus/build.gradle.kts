version = "1.0.0"
description = "Shows the other user's custom status in the DM channel header"

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Initial release — custom status shown in DM header
        """.trimIndent(),
    )
    deploy.set(true)
}
