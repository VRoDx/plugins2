package com.github.aliucordplugins

import android.content.Context
import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.aliucord.utils.DimenUtils
import com.discord.stores.StoreStream
import com.discord.widgets.chat.list.WidgetChatList

/**
 * DMCustomStatus
 *
 * Shows the recipient's Discord custom status (text + emoji) inside a small
 * badge below the username in the top-left DM channel header area.
 *
 * How it works:
 *   We patch WidgetChatList.onViewBound / configureUI so that after Discord
 *   populates the toolbar, we look up the other user's presence custom status
 *   from StoreStream.getPresences() and inject a small TextView beneath the
 *   existing title/subtitle area in the action bar.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class DMCustomStatus : Plugin() {

    companion object {
        private const val STATUS_VIEW_TAG = "dm_custom_status_view"
    }

    override fun start(context: Context) {
        patcher.after<WidgetChatList>(
            "configureUI",
            com.discord.widgets.chat.list.WidgetChatListModel::class.java,
        ) { param ->
            val model = param.args[0] as? com.discord.widgets.chat.list.WidgetChatListModel
                ?: return@after

            // Only apply to DM channels (type 1 = DM, type 3 = group DM)
            val channel = model.channel ?: return@after
            if (channel.type != 1) return@after

            val recipientId = channel.recipients?.firstOrNull() ?: return@after

            // Get presence / activities for the recipient
            val presence = StoreStream.getPresences().getPresence(recipientId) ?: return@after
            val customActivity = presence.activities?.firstOrNull { it.type == 4 } // type 4 = Custom Status

            // Find or create our status TextView in the toolbar
            val toolbar = this.`appbar`?.toolbar ?: return@after

            // Remove any existing status view
            toolbar.findViewWithTag<View>(STATUS_VIEW_TAG)?.let {
                (it.parent as? LinearLayout)?.removeView(it)
            }

            if (customActivity == null) return@after

            val emoji = customActivity.emoji?.name?.let { "$it " } ?: ""
            val statusText = customActivity.state ?: return@after
            val fullText = "$emoji$statusText"

            val dp4 = DimenUtils.dpToPx(4)
            val dp12 = DimenUtils.dpToPx(12)

            val statusView = TextView(toolbar.context).apply {
                tag = STATUS_VIEW_TAG
                text = fullText
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(Color.parseColor("#B5BAC1"))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(dp4, 0, dp4, 0)
                gravity = Gravity.CENTER_VERTICAL
            }

            // Try to insert after the existing title container in the toolbar
            val titleContainer = toolbar.getChildAt(0) as? LinearLayout
            if (titleContainer != null) {
                titleContainer.addView(statusView)
            } else {
                toolbar.addView(statusView)
            }
        }
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
