version = "1.0.0"
description = "Renders gradient role colors on usernames like legacy Discord"

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Initial release — gradient role colors on usernames
        """.trimIndent(),
    )
    deploy.set(true)
}
