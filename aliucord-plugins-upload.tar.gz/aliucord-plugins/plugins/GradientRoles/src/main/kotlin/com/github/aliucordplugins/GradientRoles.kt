package com.github.aliucordplugins

import android.content.Context
import android.graphics.LinearGradient
import android.graphics.Shader
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.TextView
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.discord.stores.StoreStream
import com.discord.widgets.chat.list.adapter.WidgetChatListAdapterItemMessage
import com.discord.widgets.chat.list.entries.ChatListEntry
import com.discord.widgets.chat.list.entries.MessageEntry

/**
 * GradientRoles
 *
 * Applies a horizontal linear gradient across usernames in chat based on the
 * user's two highest-priority colored roles — just like the old Discord desktop
 * behavior where role colors blended from one hue to another.
 *
 * How it works:
 *   1. After each message item is configured, we find the author's roles from
 *      the guild member store.
 *   2. We collect up to 2 colored roles (highest priority first).
 *   3. If 2 colors exist, we build a LinearGradient shader and apply it to the
 *      username TextView via a custom ReplacementSpan.
 *   4. If only 1 color exists, we fall back to a solid ForegroundColorSpan.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class GradientRoles : Plugin() {

    override fun start(context: Context) {
        patcher.after<WidgetChatListAdapterItemMessage>(
            "onConfigure",
            Int::class.java,
            ChatListEntry::class.java,
        ) { param ->
            val entry = param.args[1] as? MessageEntry ?: return@after
            val message = entry.message
            if (message.isLoading) return@after

            val guildId = message.guildId ?: return@after
            val authorId = message.author.id

            // Get member roles for this guild
            val guildStore = StoreStream.getGuilds()
            val rolesStore = StoreStream.getGuildRoles()
            val memberStore = StoreStream.getGuildMembers()

            val member = memberStore.getMember(guildId, authorId) ?: return@after
            val allRoles = rolesStore.getGuildRoles(guildId) ?: return@after

            // Collect colored roles sorted by position (highest first)
            val coloredRoles = member.roles
                .mapNotNull { roleId -> allRoles[roleId] }
                .filter { it.color != 0 }
                .sortedByDescending { it.position }

            if (coloredRoles.isEmpty()) return@after

            // Find the username TextView in this item view
            val usernameView = this.binding?.chatListAdapterItemMessageUsername
                ?: return@after

            val username = usernameView.text?.toString() ?: return@after

            if (coloredRoles.size == 1) {
                // Single role — solid color
                val spannable = SpannableString(username)
                spannable.setSpan(
                    ForegroundColorSpan(coloredRoles[0].color or 0xFF000000.toInt()),
                    0,
                    username.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
                )
                usernameView.text = spannable
            } else {
                // Two+ roles — gradient
                val colorStart = coloredRoles[0].color or 0xFF000000.toInt()
                val colorEnd = coloredRoles[1].color or 0xFF000000.toInt()
                applyGradient(usernameView, colorStart, colorEnd)
            }
        }
    }

    private fun applyGradient(textView: TextView, colorStart: Int, colorEnd: Int) {
        textView.post {
            val width = textView.width.toFloat()
            if (width <= 0f) return@post

            val paint = textView.paint
            val gradient = LinearGradient(
                0f, 0f, width, 0f,
                intArrayOf(colorStart, colorEnd),
                null,
                Shader.TileMode.CLAMP,
            )
            paint.shader = gradient
            textView.invalidate()
        }
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
