version = "1.0.0"
description = "Shows a loading animation while profile effects and decorations load"

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Initial release — profile effect loader animation
        """.trimIndent(),
    )
    deploy.set(true)
}
