package com.github.aliucordplugins

import android.animation.ValueAnimator
import android.content.Context
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.aliucord.patcher.before
import com.aliucord.utils.DimenUtils
import com.discord.widgets.user.profile.UserProfileEffectView

/**
 * ProfileEffectLoader
 *
 * Adds a smooth shimmer/pulse loading animation to the profile effect and
 * avatar decoration area while the effect asset is being fetched from the network.
 *
 * How it works:
 *   Discord's UserProfileEffectView starts invisible and becomes visible only when
 *   the remote Lottie/WebP asset finishes loading. We inject a "shimmer" overlay
 *   FrameLayout into the same parent as the effect view. When the effect view
 *   becomes visible (i.e. the asset loaded), we fade out and remove our overlay.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class ProfileEffectLoader : Plugin() {

    companion object {
        private const val LOADER_TAG = "profile_effect_loader_overlay"
    }

    override fun start(context: Context) {
        // Before the effect view is shown, inject our loader overlay
        patcher.before<UserProfileEffectView>(
            "setEffect",
            com.discord.api.user.UserProfileEffect::class.java,
        ) { _ ->
            val parent = this.parent as? FrameLayout ?: return@before
            showLoader(parent)
        }

        // After the effect view finishes loading, hide our loader
        patcher.after<UserProfileEffectView>(
            "onEffectLoaded",
        ) { _ ->
            val parent = this.parent as? FrameLayout ?: return@after
            hideLoader(parent)
        }
    }

    private fun showLoader(parent: FrameLayout) {
        // Remove existing loader if any
        parent.findViewWithTag<View>(LOADER_TAG)?.let { parent.removeView(it) }

        val loaderView = View(parent.context).apply {
            tag = LOADER_TAG
            setBackgroundColor(0x33FFFFFF) // translucent white shimmer base
            alpha = 0f
        }

        val size = DimenUtils.dpToPx(80)
        parent.addView(loaderView, FrameLayout.LayoutParams(size, size).also {
            it.gravity = android.view.Gravity.CENTER
        })

        // Pulse animation
        ValueAnimator.ofFloat(0.1f, 0.45f, 0.1f).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { animator ->
                loaderView.alpha = animator.animatedValue as Float
            }
            start()
        }
    }

    private fun hideLoader(parent: FrameLayout) {
        val loaderView = parent.findViewWithTag<View>(LOADER_TAG) ?: return
        loaderView.animate()
            .alpha(0f)
            .setDuration(300)
            .withEndAction { parent.removeView(loaderView) }
            .start()
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
