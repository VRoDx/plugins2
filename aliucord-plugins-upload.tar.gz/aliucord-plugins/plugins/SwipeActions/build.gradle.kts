version = "1.0.0"
description = "Swipe right-to-left on messages: reply to others (if DM open) or edit/reply your own"

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Initial release — swipe to reply or edit messages
        """.trimIndent(),
    )
    deploy.set(true)
}
