package com.github.aliucordplugins

import android.content.Context
import android.view.MotionEvent
import android.view.View
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.discord.stores.StoreStream
import com.discord.utilities.permissions.PermissionUtils
import com.discord.widgets.chat.list.adapter.WidgetChatListAdapterItemMessage
import com.discord.widgets.chat.list.entries.ChatListEntry
import com.discord.widgets.chat.list.entries.MessageEntry
import kotlin.math.abs

/**
 * SwipeActions
 *
 * Adds swipe-right-to-left gesture on chat messages with different behaviours:
 *
 * SOMEONE ELSE'S MESSAGE
 *   - DM is open (you can message them):  short OR long swipe → Reply to their message
 *   - DM is closed (requests):            swipe does nothing (can't reply to strangers)
 *
 * YOUR OWN MESSAGE
 *   - Long swipe (> threshold):           Edit the message
 *   - Short swipe (< threshold):          Reply to your own message
 *
 * Implementation approach:
 *   We attach a custom OnTouchListener to each message item view after
 *   WidgetChatListAdapterItemMessage.onConfigure() runs. The listener tracks
 *   horizontal velocity and dispatches the appropriate action.
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class SwipeActions : Plugin() {

    companion object {
        /** Minimum horizontal distance (px) to register as a swipe */
        private const val SWIPE_MIN_DISTANCE = 80f
        /** Distance threshold that separates a short swipe from a long swipe */
        private const val SWIPE_LONG_THRESHOLD = 220f
        /** Maximum vertical drift allowed for the gesture to count as horizontal */
        private const val SWIPE_MAX_VERTICAL = 120f
    }

    override fun start(context: Context) {
        patcher.after<WidgetChatListAdapterItemMessage>(
            "onConfigure",
            Int::class.java,
            ChatListEntry::class.java,
        ) { param ->
            val entry = param.args[1] as? MessageEntry ?: return@after
            val message = entry.message
            if (message.isLoading) return@after

            val itemView: View = this.itemView
            val channel = StoreStream.getChannelsSelected().selectedChannel ?: return@after
            val currentUserId = StoreStream.getUsers().me?.id ?: return@after
            val isOwnMessage = message.author.id == currentUserId

            itemView.setOnTouchListener(object : View.OnTouchListener {
                private var startX = 0f
                private var startY = 0f

                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.rawX
                            startY = event.rawY
                        }
                        MotionEvent.ACTION_UP -> {
                            val dx = startX - event.rawX  // positive = swipe left
                            val dy = abs(event.rawY - startY)

                            if (dx >= SWIPE_MIN_DISTANCE && dy <= SWIPE_MAX_VERTICAL) {
                                val isLongSwipe = dx >= SWIPE_LONG_THRESHOLD

                                if (isOwnMessage) {
                                    if (isLongSwipe) {
                                        // Edit own message
                                        openEditMessage(message)
                                    } else {
                                        // Reply to own message
                                        openReply(message, channel)
                                    }
                                } else {
                                    // Someone else's message
                                    val canMessage = canMessageInChannel(channel, currentUserId)
                                    if (canMessage) {
                                        openReply(message, channel)
                                    }
                                    // else: closed DMs — do nothing
                                }
                                return true
                            }
                        }
                    }
                    return false
                }
            })
        }
    }

    private fun canMessageInChannel(
        channel: com.discord.models.channel.Channel,
        userId: Long,
    ): Boolean {
        // For DM channels (type=1), check if the channel is accepting messages.
        // A channel with message_requests=true and not yet accepted means it's "closed".
        if (channel.type == 1) {
            return channel.isMessageRequestChannel != true || channel.isMessageRequestAccepted == true
        }
        // For guild channels, check SEND_MESSAGES permission
        val permissions = StoreStream.getPermissions().getPermissionsByChannel()[channel.id] ?: return false
        return PermissionUtils.can(
            com.discord.utilities.permissions.Permission.SEND_MESSAGES,
            permissions,
        )
    }

    private fun openReply(
        message: com.discord.models.message.Message,
        channel: com.discord.models.channel.Channel,
    ) {
        // Dispatch a reply action through the pending reply store
        StoreStream.getPendingReplies().startReply(
            com.discord.stores.PendingReplyStore.PendingReply(
                message = message,
                channel = channel,
                mentionUser = true,
                showMentionToggle = channel.type != 1,
            ),
        )
    }

    private fun openEditMessage(message: com.discord.models.message.Message) {
        StoreStream.getMessageEditing().startEditing(message)
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
