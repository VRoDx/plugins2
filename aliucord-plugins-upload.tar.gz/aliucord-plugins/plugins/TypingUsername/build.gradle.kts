version = "1.0.0"
description = "Shows the actual @username in typing indicators instead of display name"

aliucord {
    changelog.set(
        """
        # 1.0.0
        * Initial release — fix typing indicator to show @username
        """.trimIndent(),
    )
    deploy.set(true)
}
