package com.github.aliucordplugins

import android.content.Context
import com.aliucord.annotations.AliucordPlugin
import com.aliucord.entities.Plugin
import com.aliucord.patcher.after
import com.discord.stores.StoreUserTyping
import com.discord.widgets.chat.input.WidgetChatInput
import com.discord.models.user.User

/**
 * TypingUsername
 *
 * Fixes the "X is typing..." indicator in DMs to show the actual @username
 * of the person typing instead of their display name.
 *
 * How it works:
 *   Discord builds the typing string using the user's "display name" (globalName or nickname).
 *   We patch the method that formats the typing text and replace the display name
 *   with the raw username so it shows e.g. "@someuser is typing..." instead of
 *   "Some Display Name is typing..."
 */
@AliucordPlugin(requiresRestart = false)
@Suppress("unused")
class TypingUsername : Plugin() {

    override fun start(context: Context) {
        // WidgetChatInput$configureChatInput patches the typing bar text.
        // The method getTypingText() (or equivalent) returns a CharSequence such as
        // "Alice is typing..." using the display name. We intercept after the call
        // and replace any matched display name with the @username.
        //
        // Aliucord exposes StoreUserTyping which holds a map of channelId -> (userId -> timestamp).
        // We walk that map to find who is typing in the current channel and substitute names.

        patcher.after<WidgetChatInput>(
            "configureChatInput",
            com.discord.widgets.chat.input.WidgetChatInputModel::class.java,
        ) { param ->
            val model = param.args[0] as? com.discord.widgets.chat.input.WidgetChatInputModel
                ?: return@after

            // Retrieve the typing users from the model's channel state
            val typingUsers = model.typingUsers ?: return@after
            if (typingUsers.isEmpty()) return@after

            // For each typing user, replace display name with @username in the typing text view
            val typingView = this.`typingText` ?: return@after

            var text = typingView.text?.toString() ?: return@after

            for (user in typingUsers) {
                val displayName = user.globalName ?: user.username
                val username = user.username
                if (displayName != username) {
                    text = text.replace(displayName, "@$username")
                }
            }

            typingView.text = text
        }
    }

    override fun stop(context: Context) {
        patcher.unpatchAll()
    }
}
